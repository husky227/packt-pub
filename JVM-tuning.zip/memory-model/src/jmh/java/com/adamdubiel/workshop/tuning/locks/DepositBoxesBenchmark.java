package com.adamdubiel.workshop.tuning.locks;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Group;
import org.openjdk.jmh.annotations.GroupThreads;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class DepositBoxesBenchmark {

    private static final int READERS = 1;
    private static final int WRITERS = 200;

    @State(Scope.Benchmark)
    public static class BoxState {

        public DepositBox synchronizedDepositBox = new DepositBoxes.SynchronizedDepositBox();

        public DepositBox lockedDepositBox = new DepositBoxes.LockedDepositBox();

        public DepositBox readWriteDepositBox = new DepositBoxes.ReadWriteDepositBox();

        public DepositBox optimizedReadWriteDepositBox = new DepositBoxes.OptimizedReadWriteDepositBox();

        public DepositBox optimizedSynchronizedDepositBox = new DepositBoxes.OptimizedSynchronizedDepositBox();

        public DepositBox stampedDepositBox = new DepositBoxes.StampedDepositBox();

        public DepositBox stampedOptimisticDepositBox = new DepositBoxes.StampedOptimisticDepositBox();

        public AtomicLong counter = new AtomicLong(0);

        public String[] values;

        @Setup
        public void init() {
            values = new String[10000];
            Random random = new Random();
            for(int i = 0; i < values.length; ++i) {
                values[i] = "content" + random.nextInt();
            }
        }

        public String nextValue() {
            return values[(int) counter.incrementAndGet() % values.length];
        }

    }

    @Benchmark
    @Fork(1)
    @Group("synchronized")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent synchronizedDepositBoxGet(BoxState state) {
        return state.synchronizedDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("synchronized")
    @GroupThreads(WRITERS)
    public String synchronizedDepositBoxPut(BoxState state) {
        return state.synchronizedDepositBox.put(state.nextValue());
    }

    @Benchmark
    @Fork(1)
    @Group("locked")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent lockedDepositBoxGet(BoxState state) {
        return state.lockedDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("locked")
    @GroupThreads(WRITERS)
    public String lockedDepositBoxPut(BoxState state) {
        return state.lockedDepositBox.put(state.nextValue());
    }

    @Benchmark
    @Fork(1)
    @Group("readWrite")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent readWriteDepositBoxGet(BoxState state) {
        return state.readWriteDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("readWrite")
    @GroupThreads(WRITERS)
    public String readWriteDepositBoxPut(BoxState state) {
        return state.readWriteDepositBox.put(state.nextValue());
    }

    @Benchmark
    @Fork(1)
    @Group("optimizedReadWrite")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent optimizedReadWriteDepositBoxGet(BoxState state) {
        return state.optimizedReadWriteDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("optimizedReadWrite")
    @GroupThreads(WRITERS)
    public String optimizedReadWriteDepositBoxPut(BoxState state) {
        return state.optimizedReadWriteDepositBox.put(state.nextValue());
    }

    @Benchmark
    @Fork(1)
    @Group("optimizedSynchronized")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent optimizedSynchronizedDepositBoxGet(BoxState state) {
        return state.optimizedSynchronizedDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("optimizedSynchronized")
    @GroupThreads(WRITERS)
    public String optimizedSynchronizedDepositBoxPut(BoxState state) {
        return state.optimizedSynchronizedDepositBox.put(state.nextValue());
    }

    @Benchmark
    @Fork(1)
    @Group("stamped")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent stampedDepositBoxGet(BoxState state) {
        return state.stampedDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("stamped")
    @GroupThreads(WRITERS)
    public String stampedDepositBoxPut(BoxState state) {
        return state.stampedDepositBox.put(state.nextValue());
    }

    @Benchmark
    @Fork(1)
    @Group("stampedOptimistic")
    @GroupThreads(READERS)
    public DepositBox.DepositBoxContent stampedOptimisticDepositBoxGet(BoxState state) {
        return state.stampedOptimisticDepositBox.get();
    }

    @Benchmark
    @Fork(1)
    @Group("stampedOptimistic")
    @GroupThreads(WRITERS)
    public String stampedOptimisticDepositBoxPut(BoxState state) {
        return state.stampedOptimisticDepositBox.put(state.nextValue());
    }
}
