package com.adamdubiel.workshop.tuning.threads;

import com.codahale.metrics.MetricRegistry;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Level;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.TearDown;
import org.openjdk.jmh.annotations.Threads;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

public class InstrumentedThreadPoolBenchmark {

    private static final int THREADS = 10;

    @State(Scope.Benchmark)
    public static class ThreadsState {

        public final AtomicLong counter = new AtomicLong(0);

        public final ExecutorService threadPool = Executors.newFixedThreadPool(THREADS);

        public final InstrumentedExecutorService instrumentedThreadPool = new InstrumentedExecutorService(
                Executors.newFixedThreadPool(THREADS),
                new MetricRegistry(),
                "threadPool"
        );

        @TearDown(Level.Trial)
        public void tearDown() {
            threadPool.shutdownNow();
            instrumentedThreadPool.shutdownNow();
        }
    }

    @Benchmark
    @Fork(1)
    @Threads(THREADS)
    public Thread newThread(ThreadsState state) throws InterruptedException {
        Thread thread = new Thread(() -> state.counter.getAndIncrement());
        thread.start();
        thread.join();
        return thread;
    }

    @Benchmark
    @Fork(1)
    @Threads(THREADS)
    public Future<Long> threadPool(ThreadsState state) throws InterruptedException, ExecutionException {
        Future<Long> f = state.threadPool.submit(() -> state.counter.getAndIncrement());
        f.get();
        return f;
    }

    @Benchmark
    @Fork(1)
    @Threads(THREADS)
    public Future<Long> instrumentedThreadPool(ThreadsState state) throws InterruptedException, ExecutionException {
        Future<Long> f = state.instrumentedThreadPool.submit(() -> state.counter.getAndIncrement());
        f.get();
        return f;
    }
}
