package com.adamdubiel.workshop.tuning.threads;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Level;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.TearDown;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

public class ThreadsBenchmark {

    @State(Scope.Benchmark)
    public static class ThreadsState {

        public final AtomicLong counter = new AtomicLong(0);

        public final ExecutorService threadPool = Executors.newFixedThreadPool(1);

        @TearDown(Level.Trial)
        public void tearDown() {
            threadPool.shutdownNow();
        }
    }

    @Benchmark
    @Fork(1)
    public Thread newThread(ThreadsState state) throws InterruptedException {
        Thread thread = new Thread(() -> state.counter.getAndIncrement());
        thread.start();
        thread.join();
        return thread;
    }

    @Benchmark
    @Fork(1)
    public Future<Long> threadPool(ThreadsState state) throws InterruptedException, ExecutionException {
        Future<Long> f = state.threadPool.submit(() -> state.counter.getAndIncrement());
        f.get();
        return f;
    }
}
