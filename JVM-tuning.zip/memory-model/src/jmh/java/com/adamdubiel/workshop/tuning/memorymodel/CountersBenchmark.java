package com.adamdubiel.workshop.tuning.memorymodel;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.Threads;

public class CountersBenchmark {

    @State(Scope.Benchmark)
    public static class CounterState {

        public Counter synchronizedCounter = new Counters.SynchronizedCounter();

        public Counter atomicCounter = new Counters.AtomicCounter();

        public Counter casCounter = new Counters.CasCounter();

    }

    @Benchmark
    @Fork(1)
    @Threads(2)
    public int synchronizedCounter(CounterState state) {
        state.synchronizedCounter.add();
        return state.synchronizedCounter.value();
    }

    @Benchmark
    @Fork(1)
    @Threads(2)
    public int atomicCounter(CounterState state) {
        state.atomicCounter.add();
        return state.atomicCounter.value();
    }

    @Benchmark
    @Fork(1)
    @Threads(2)
    public int casCounter(CounterState state) {
        state.casCounter.add();
        return state.casCounter.value();
    }
}
