package com.adamdubiel.workshop.tuning.threads;

class ThreadsSpawner {

    public static void main(String[] args) {
        int i = 0;
        for (; ; ) {
            Thread thread = new Thread(() -> {
                try {
                    Thread.sleep(100000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            thread.start();
            i++;
            System.out.println("Spawned " + i + " threads");
        }
    }

}
