package com.adamdubiel.workshop.tuning.infrastructure;

import sun.misc.Unsafe;

import java.lang.reflect.Field;

public final class TheUnsafe {

    private static Unsafe unsafe;

    static {
        try {
            Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
            unsafeField.setAccessible(true);
            unsafe = (Unsafe) unsafeField.get(null);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            System.err.println("Failed to load Unsafe! Exiting.");
            System.exit(1);
        }
    }

    public static Unsafe unsafe() {
        return unsafe;
    }
}
