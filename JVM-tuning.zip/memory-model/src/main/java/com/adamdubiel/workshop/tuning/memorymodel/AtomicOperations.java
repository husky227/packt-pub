package com.adamdubiel.workshop.tuning.memorymodel;

import com.adamdubiel.workshop.tuning.infrastructure.TheUnsafe;
import sun.misc.Unsafe;

import java.util.concurrent.ExecutionException;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class AtomicOperations {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        RaceConditionTester tester = new RaceConditionTester();

        boolean passed = tester.test(() -> new CasCounter());
        summary(passed);
    }

    static void summary(boolean passed) {
        if (passed) {
            output("Test passed - well done! Hope you were not using AtomicInteger :>");
        } else {
            output("Test failed: race condition detected.");
        }
    }

    public static class CasCounter implements Counter {

        private static long offset = 0L;
        private volatile int counter = 0;

        private static Unsafe unsafe = null;

        static {
            try {
                unsafe = TheUnsafe.unsafe();
                offset = unsafe.objectFieldOffset(CasCounter.class.getDeclaredField("counter"));
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void add() {
            int temp;
            do {
                temp = counter;
            } while (!unsafe.compareAndSwapInt(this, offset, temp, temp + 1));
        }

        @Override
        public int value() {
            return counter;
        }
    }
}
