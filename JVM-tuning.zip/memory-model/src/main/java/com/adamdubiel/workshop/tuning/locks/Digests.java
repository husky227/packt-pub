package com.adamdubiel.workshop.tuning.locks;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class Digests {

    static String computeHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.update(content.getBytes(StandardCharsets.UTF_8));
            return new String(digest.digest(), StandardCharsets.UTF_8);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException("Unknonw hashing algorithm: SHA-1, is your JVM ok?", e);
        }
    }

}
