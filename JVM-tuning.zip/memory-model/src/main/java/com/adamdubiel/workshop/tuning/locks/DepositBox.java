package com.adamdubiel.workshop.tuning.locks;

public interface DepositBox {

    String put(String content);

    DepositBoxContent get();

    class DepositBoxContent {
        private final String content;
        private final String hash;

        public DepositBoxContent(String content, String hash) {
            this.content = content;
            this.hash = hash;
        }

        public String getContent() {
            return content;
        }

        public String getHash() {
            return hash;
        }
    }
}
