package com.adamdubiel.workshop.tuning.locks;

import com.adamdubiel.workshop.tuning.infrastructure.Completables;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

class RaceConditionTester {

    boolean test(Supplier<DepositBox> depositBoxSupplier) throws InterruptedException {
        int threadCount = 20;
        int tries = 1000;

        ExecutorService threadPool = Executors.newFixedThreadPool(threadCount);

        int mismatchCount = 0;
        for (int i = 0; i < tries; ++i) {
            if (!testConcurrently(depositBoxSupplier.get(), threadPool, threadCount)) {
                mismatchCount++;
            }
        }

        threadPool.shutdownNow();

        summary(mismatchCount, tries, threadCount);
        return mismatchCount == 0;
    }

    static boolean testConcurrently(DepositBox depositBox, ExecutorService threadPool, int threadCount) throws InterruptedException {
        List<CompletableFuture<Void>> futures = new ArrayList<>(threadCount);
        for (int i = 0; i < threadCount; ++i) {
            int s = i;
            futures.add(
                    CompletableFuture.runAsync(() -> {
                        depositBox.put("content" + s);
                    }, threadPool)
            );
        }

        Completables.allCompleted(futures);
        DepositBox.DepositBoxContent content = depositBox.get();
        return content.getHash().equals(Digests.computeHash(content.getContent()));
    }


    static void summary(int failureCount, int totalCount, int threads) {
        double failurePercent = (failureCount / (double) totalCount) * (double) 100;

        System.out.println(String.format(
                "Detected race conditions in: %d/%d tries (%.1f%%) [%d threads]",
                failureCount, totalCount, failurePercent, threads
        ));
    }
}
