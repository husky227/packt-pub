package com.adamdubiel.workshop.tuning.memorymodel;

import com.adamdubiel.workshop.tuning.infrastructure.Completables;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class Visibility {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        int threadCount = 10;

        output("[1/7] Creating thread pool with " + (threadCount + 1) + " threads");
        ExecutorService threadPool = Executors.newFixedThreadPool(threadCount + 1);

        boolean visibilityProblems = !runConcurrently(threadPool, threadCount);

        output("[6/7] Shutting down the thread pool (more on this later)");
        threadPool.shutdownNow();

        output("[7/7] Visibility problems encountered? " + visibilityProblems);
    }

    static class Switch {
        private volatile boolean enabled = true;

        void disable() {
            enabled = false;
        }

        boolean enabled() {
            return enabled;
        }
    }

    static boolean runConcurrently(ExecutorService threadPool, int threadCount) {
        output("[2/7] Creating single switch object to control all worker threads");
        Switch object = new Switch();

        List<CompletableFuture<Void>> futures = new ArrayList<>(threadCount);
        output("[3/7] Spawning " + threadCount + " worker threads working while switch is enabled");
        for (int i = 0; i < threadCount; ++i) {
            futures.add(
                    CompletableFuture.runAsync(() -> {
                        while(object.enabled()) {
                            // waiting
                        }
                    }, threadPool)
            );
        }

        output("[4/7] Creating new thread that immediately disables the switch");
        threadPool.submit(() -> object.disable());

        output("[5/7] Checking if all workers stopped working");
        return Completables.allCompleted(futures, 100);
    }

}
