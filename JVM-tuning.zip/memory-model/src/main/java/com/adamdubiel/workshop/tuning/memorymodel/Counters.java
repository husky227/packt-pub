package com.adamdubiel.workshop.tuning.memorymodel;

import com.adamdubiel.workshop.tuning.infrastructure.TheUnsafe;
import sun.misc.Unsafe;

import java.util.concurrent.atomic.AtomicInteger;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

public class Counters {

    public static class SynchronizedCounter implements Counter {

        private int counter = 0;

        @Override
        public synchronized void add() {
            counter++;
        }

        @Override
        public synchronized int value() {
            return counter;
        }
    }

    public static class AtomicCounter implements Counter {

        private AtomicInteger counter = new AtomicInteger(0);

        @Override
        public void add() {
            counter.incrementAndGet();
        }

        @Override
        public int value() {
            return counter.get();
        }
    }

    public static class CasCounter implements Counter {

        private static long offset = 0L;
        private volatile int counter = 0;

        private static Unsafe unsafe = null;

        static {
            try {
                unsafe = TheUnsafe.unsafe();
                offset = unsafe.objectFieldOffset(CasCounter.class.getDeclaredField("counter"));
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void add() {
            int temp;
            do {
                temp = counter;
            } while (!unsafe.compareAndSwapInt(this, offset, temp, temp + 1));
        }

        @Override
        public int value() {
            return counter;
        }
    }

    public static final void main(String[] varargs) throws InterruptedException {
        RaceConditionTester tester = new RaceConditionTester();

        boolean synchronizedPassed = tester.test(() -> new SynchronizedCounter());
        outputResult("SynchronizedCounter", synchronizedPassed);

        boolean atomicPassed = tester.test(() -> new AtomicCounter());
        outputResult("AtomicCounter", atomicPassed);

        boolean casPassed = tester.test(() -> new CasCounter());
        outputResult("CasCounter", casPassed);
    }

    private static void outputResult(String name, boolean passed) {
        if (passed) {
            output(name + ": PASSED");
        } else {
            output(name + ": FAILED");
        }
    }
}
