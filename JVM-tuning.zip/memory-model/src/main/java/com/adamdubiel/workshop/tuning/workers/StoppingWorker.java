package com.adamdubiel.workshop.tuning.workers;

import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class StoppingWorker {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        ExecutorService threadPool = Executors.newFixedThreadPool(1);

        Worker worker = new Worker();
        CompletableFuture<Boolean> future = CompletableFuture.supplyAsync(worker, threadPool);

        // make sure we don't get into any data races
        // thread pool might shutdown before we get to start worker thread
        Thread.sleep(10);

        future.exceptionally((e) -> {
            output("As expected, this future completed exceptionally");
            return false;
        });

        try {
            output("[1/7] Cancelling worker future");
            future.cancel(true);
            output("[2/7] Waiting for future to join");
            future.join();
        } catch (CancellationException exception) {
            output("[3/7] Cancelled: " + future.isCancelled());
        }

        output("[4/7] Waiting for thread pool to shutdown gracefully");
        threadPool.shutdown();
        threadPool.awaitTermination(1, TimeUnit.SECONDS);


        output("[5/7] Waiting for threads to be forcefully shut down");
        threadPool.shutdownNow();

        output("[6/7] Cleanup: Gracefully shutting down worker");
        worker.stop();
        output("[7/7] Was thread stopped forcefully (we hope it was): " + worker.wasForcefullyStopped());
    }

    static class Worker implements Supplier<Boolean> {

        private boolean run = true;

        private boolean forcefullyStopped = false;

        void stop() {
            this.run = false;
        }

        boolean wasForcefullyStopped() {
            return forcefullyStopped;
        }

        @Override
        public Boolean get() {
            try {
                while (run) {
                    // running
                }
            } catch (Exception exception) {
                System.out.println("Caught exception in worker thread: " + exception.getClass().getSimpleName());
            }
            return true;
        }
    }
}
