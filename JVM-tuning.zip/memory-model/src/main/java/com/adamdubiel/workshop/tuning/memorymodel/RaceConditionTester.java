package com.adamdubiel.workshop.tuning.memorymodel;

import com.adamdubiel.workshop.tuning.infrastructure.Completables;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

class RaceConditionTester {

    boolean test(Supplier<Counter> counterSupplier) throws InterruptedException {
        int threadCount = 40;
        int tries = 1000;

        ExecutorService threadPool = Executors.newFixedThreadPool(threadCount);

        int mismatchCount = 0;
        for (int i = 0; i < tries; ++i) {
            if (testConcurrently(counterSupplier.get(), threadPool, threadCount) != threadCount) {
                mismatchCount++;
            }
        }

        threadPool.shutdownNow();

        summary(mismatchCount, tries, threadCount);
        return mismatchCount == 0;
    }

    static int testConcurrently(Counter counter, ExecutorService threadPool, int threadCount) throws InterruptedException {
        List<CompletableFuture<Void>> futures = new ArrayList<>(threadCount);
        for (int i = 0; i < threadCount; ++i) {
            futures.add(
                    CompletableFuture.runAsync(() -> {
                        counter.add();
                    }, threadPool)
            );
        }

        Completables.allCompleted(futures);
        return counter.value();
    }


    static void summary(int failureCount, int totalCount, int threads) {
        double failurePercent = (failureCount / (double) totalCount) * (double) 100;

        System.out.println(String.format(
                "Detected race conditions in: %d/%d tries (%.1f%%) [%d threads]",
                failureCount, totalCount, failurePercent, threads
        ));
    }
}
