package com.adamdubiel.workshop.tuning.infrastructure;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Completables {

    public static <T> void allCompleted(Collection<CompletableFuture<T>> futures) {
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
    }

    public static <T> boolean allCompleted(Collection<CompletableFuture<T>> futures, long timeoutMillis) {
        try {
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).get(timeoutMillis, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            return false;
        }
        return true;
    }

}
