package com.adamdubiel.workshop.tuning.threads;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class ThreadPoolOverflow {

    private static final int THREAD_POOL_SIZE = 10;

    private static final int THREADS = 10_000_000;

    private static final long SLEEP_TIME = Duration.of(10, ChronoUnit.MINUTES).toMillis();

    public static final void main(String[] args) throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

        // write the overflow code
        // create pool size with THREAD_POOL_SIZE size
        // start THREADS of threads, each sleeping SLEEP_TIME
        // what happens? don't stop the program, let it run

        executorService.shutdownNow();
    }

}
