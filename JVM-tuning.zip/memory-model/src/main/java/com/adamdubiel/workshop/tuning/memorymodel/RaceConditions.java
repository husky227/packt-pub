package com.adamdubiel.workshop.tuning.memorymodel;

import com.adamdubiel.workshop.tuning.infrastructure.Completables;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class RaceConditions {

    public static void main(String[] args) throws InterruptedException {
        int threadCount = 10;
        int tries = 1000;

        output("[1/3] Going to run race condition detector " + tries + " times, each time using " + threadCount + " threads");

        ExecutorService threadPool = Executors.newFixedThreadPool(threadCount);

        int mismatchCount = 0;
        for (int i = 0; i < tries; ++i) {
            if (runConcurrently(threadPool, threadCount) != threadCount) {
                mismatchCount++;
            }
        }

        output("[2/3] Shutting down the thread pool (more on this later)");
        threadPool.shutdownNow();

        summary(mismatchCount, tries, threadCount);
    }

    static class SimpleCounter implements Counter {
        private int counter = 0;

        @Override
        public void add() {
            counter++;
        }

        @Override
        public int value() {
            return counter;
        }
    }

    static int runConcurrently(ExecutorService threadPool, int threadCount) throws InterruptedException {
        Counter object = new SimpleCounter();

        List<CompletableFuture<Void>> futures = new ArrayList<>(threadCount);
        for (int i = 0; i < threadCount; ++i) {
            futures.add(
                    CompletableFuture.runAsync(() -> {
                        object.add();
                    }, threadPool)
            );
        }

        Completables.allCompleted(futures);
        return object.value();
    }


    static void summary(int failureCount, int totalCount, int threads) {
        double failurePercent = (failureCount / (double) totalCount) * (double) 100;

        System.out.println(String.format(
                "[3/3] Detected race conditions in: %d/%d tries (%.1f%%) [%d threads]",
                failureCount, totalCount, failurePercent, threads
        ));
    }
}
