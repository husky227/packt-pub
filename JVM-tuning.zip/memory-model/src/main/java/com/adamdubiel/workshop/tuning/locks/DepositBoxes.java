package com.adamdubiel.workshop.tuning.locks;

import java.util.concurrent.locks.*;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class DepositBoxes {

    public static void main(String[] args) throws InterruptedException {
        RaceConditionTester tester = new RaceConditionTester();

        boolean synchronizedPassed = tester.test(() -> new SynchronizedDepositBox());
        outputResult("SynchronizedDepositBox", synchronizedPassed);

        boolean lockedPassed = tester.test(() -> new LockedDepositBox());
        outputResult("LockedDepositBox", lockedPassed);

        boolean readWritePassed = tester.test(() -> new ReadWriteDepositBox());
        outputResult("ReadWriteDepositBox", readWritePassed);

        boolean optimizedReadWritePassed = tester.test(() -> new OptimizedReadWriteDepositBox());
        outputResult("OptimizedReadWriteDepositBox", optimizedReadWritePassed);

        boolean optimizedSynchronizedPassed = tester.test(() -> new OptimizedSynchronizedDepositBox());
        outputResult("OptimizedSynchronizedDepositBox", optimizedSynchronizedPassed);

        boolean stampedDepositBox = tester.test(() -> new StampedDepositBox());
        outputResult("StampedDepositBox", stampedDepositBox);

        boolean optimisticStampedDepositBox = tester.test(() -> new StampedOptimisticDepositBox());
        outputResult("StampedOptimisticDepositBox", optimisticStampedDepositBox);
    }

    private static void outputResult(String name, boolean passed) {
        if (passed) {
            output(name + ": PASSED");
        } else {
            output(name + ": FAILED");
        }
    }

    public static class SynchronizedDepositBox implements DepositBox {

        private String contentHash;

        private String content;

        @Override
        public synchronized DepositBoxContent get() {
            return new DepositBoxContent(content, contentHash);
        }

        @Override
        public synchronized String put(String content) {
            this.contentHash = Digests.computeHash(content);
            this.content = content;
            return contentHash;
        }
    }

    public static class LockedDepositBox implements DepositBox {

        private static final Lock lock = new ReentrantLock();
        private String contentHash;
        private String content;

        @Override
        public DepositBoxContent get() {
            lock.lock();
            try {
                return new DepositBoxContent(content, contentHash);
            } finally {
                lock.unlock();
            }
        }

        @Override
        public String put(String content) {
            lock.lock();
            try {
                this.contentHash = Digests.computeHash(content);
                this.content = content;
                return contentHash;
            } finally {
                lock.unlock();
            }
        }
    }

    public static class ReadWriteDepositBox implements DepositBox {

        private static final ReadWriteLock lock = new ReentrantReadWriteLock();

        private String contentHash;

        private String content;

        @Override
        public DepositBoxContent get() {
            lock.readLock().lock();
            try {
                return new DepositBoxContent(content, contentHash);
            } finally {
                lock.readLock().unlock();
            }
        }

        @Override
        public String put(String content) {
            lock.writeLock().lock();
            try {
                this.contentHash = Digests.computeHash(content);
                this.content = content;
                return contentHash;
            } finally {
                lock.writeLock().unlock();
            }
        }
    }

    public static class OptimizedReadWriteDepositBox implements DepositBox {

        private static final ReadWriteLock lock = new ReentrantReadWriteLock();

        private String contentHash;

        private String content;

        @Override
        public DepositBoxContent get() {
            lock.readLock().lock();
            try {
                return new DepositBoxContent(content, contentHash);
            } finally {
                lock.readLock().unlock();
            }
        }

        @Override
        public String put(String content) {
            String contentHash = Digests.computeHash(content);
            lock.writeLock().lock();
            try {
                this.contentHash = contentHash;
                this.content = content;
            } finally {
                lock.writeLock().unlock();
            }
            return this.contentHash;
        }
    }

    public static class OptimizedSynchronizedDepositBox implements DepositBox {

        private String contentHash;

        private String content;

        @Override
        public synchronized DepositBoxContent get() {
            return new DepositBoxContent(content, contentHash);
        }

        @Override
        public String put(String content) {
            String contentHash = Digests.computeHash(content);
            synchronized (this) {
                this.contentHash = contentHash;
                this.content = content;
            }
            return this.contentHash;
        }
    }

    public static class StampedDepositBox implements DepositBox {

        private static final StampedLock lock = new StampedLock();

        private String contentHash;

        private String content;

        @Override
        public DepositBoxContent get() {
            long stamp = lock.readLock();
            try {
                return new DepositBoxContent(content, contentHash);
            } finally {
                lock.unlockRead(stamp);
            }
        }

        @Override
        public String put(String content) {
            String contentHash = Digests.computeHash(content);
            long stamp = lock.writeLock();
            try {
                this.contentHash = contentHash;
                this.content = content;
            } finally {
                lock.unlockWrite(stamp);
            }
            return this.contentHash;
        }
    }

    public static class StampedOptimisticDepositBox implements DepositBox {

        private static final StampedLock lock = new StampedLock();

        private String contentHash;

        private String content;

        @Override
        public DepositBoxContent get() {
            DepositBoxContent depositBoxContent;
            long stamp = lock.tryOptimisticRead();
            depositBoxContent = new DepositBoxContent(content, contentHash);
            if (!lock.validate(stamp)) {
                stamp = lock.readLock();
                try {
                    return new DepositBoxContent(content, contentHash);
                } finally {
                    lock.unlockRead(stamp);
                }
            }
            return depositBoxContent;
        }

        @Override
        public String put(String content) {
            String contentHash = Digests.computeHash(content);
            long stamp = lock.writeLock();
            try {
                this.contentHash = contentHash;
                this.content = content;
            } finally {
                lock.unlockWrite(stamp);
            }
            return this.contentHash;
        }
    }
}
