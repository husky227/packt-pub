package com.adamdubiel.workshop.tuning.threads;

import com.adamdubiel.workshop.tuning.infrastructure.Completables;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class MonitoredThreadPool {

    private static final int THREAD_POOL_SIZE = 10;

    private static final int THREADS = 2;

    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    ExecutorService measuredThreadPool(int size, int queueSize) {
        ExecutorService threadPool = null;

        // create implementation that will print metrics every 1 second

        scheduler.scheduleWithFixedDelay(() -> {
            // add printing measurements here
        }, 1, 1, TimeUnit.SECONDS);

        return threadPool;
    }

    void shutdown() {
        scheduler.shutdownNow();
    }

    public static final void main(String[] args) throws ExecutionException, InterruptedException {
        MonitoredThreadPool factory = new MonitoredThreadPool();

        ExecutorService threadPool = factory.measuredThreadPool(THREAD_POOL_SIZE, 1000);

        Runnable sleeper = () -> {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                // very bad to swallow exceptions! ;)
            }
        };

        for (; ; ) {
            List<CompletableFuture<Void>> futures = new ArrayList<>();
            for (int i = 0; i < THREADS; ++i) {
                futures.add(CompletableFuture.runAsync(() -> sleeper.run(), threadPool));
            }
            Completables.allCompleted(futures);
        }
    }
}

