package com.adamdubiel.workshop.tuning.threads;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class ThreadPoolRejectionPolicy {

    static ThreadPoolWithRejectedCounter boundedThreadPool(int size, int queueSize) {

        AtomicInteger counter = new AtomicInteger(0);

        ExecutorService executor = new ThreadPoolExecutor(size, size, 1, TimeUnit.MINUTES, new ArrayBlockingQueue<>(queueSize), (r, executor1) -> counter.incrementAndGet());

        // create implementation that will pass the test!

        return new ThreadPoolWithRejectedCounter(
                executor,
                counter::get
        );
    }

    public static final void main(String[] args) throws InterruptedException {
        int threads = 2;
        int queueSize = 10;

        ThreadPoolWithRejectedCounter threadPool = boundedThreadPool(threads, queueSize);

        boolean passed = validateThreadPool(threadPool.threadPool, threads, queueSize, threadPool.rejectedTasksCounterGetter);
        if (passed) {
            output("Passed the test! Great work.");
        } else {
            output("Test failed, either rejection policy or the queue is not well specified.");
        }
    }

    private static boolean validateThreadPool(
            ExecutorService executorService,
            int size, int queueSize,
            Supplier<Integer> rejectedTasksCounterGetter
    ) throws InterruptedException {
        for (int i = 0; i < size + queueSize + 10; ++i) {
            executorService.submit(() -> {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        }

        Thread.sleep(1000);

        int rejected = rejectedTasksCounterGetter.get();
        output("Expected to get 10 rejected tasks, got: " + rejected);
        return rejected == 10;
    }

    static class ThreadPoolWithRejectedCounter {
        private final ExecutorService threadPool;
        private final Supplier<Integer> rejectedTasksCounterGetter;

        ThreadPoolWithRejectedCounter(ExecutorService threadPool, Supplier<Integer> rejectedTasksCounterGetter) {
            this.threadPool = threadPool;
            this.rejectedTasksCounterGetter = rejectedTasksCounterGetter;
        }
    }
}
