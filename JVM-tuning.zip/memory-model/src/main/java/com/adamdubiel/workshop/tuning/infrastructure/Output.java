package com.adamdubiel.workshop.tuning.infrastructure;

public final class Output {

    public static void output(String message) {
        System.out.println(message);
    }

}
