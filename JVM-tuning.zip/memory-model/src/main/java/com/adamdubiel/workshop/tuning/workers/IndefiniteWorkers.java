package com.adamdubiel.workshop.tuning.workers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import static com.adamdubiel.workshop.tuning.infrastructure.Output.output;

class IndefiniteWorkers {

    private static ExecutorService createThreadPoll(int threads) {
        return Executors.newFixedThreadPool(threads, new NamedThreadFactory());
    }

    private static class NamedThreadFactory implements ThreadFactory {

        AtomicInteger counter = new AtomicInteger(0);

        public NamedThreadFactory() {
        }

        @Override
        public Thread newThread(Runnable r) {
            Thread thread = Executors.defaultThreadFactory().newThread(r);
            thread.setName("worker-thread-" + counter.incrementAndGet());
            return thread;
        }
    }

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        int threadPoolSize = 10;

        ExecutorService threadPool = createThreadPoll(threadPoolSize);

        List<CompletableFuture<Boolean>> futures = new ArrayList<>(threadPoolSize);
        for (int i = 0; i < threadPoolSize; ++i) {
            futures.add(
                    CompletableFuture.supplyAsync(new Worker(), threadPool)
            );
        }

        futures.forEach(f -> {
            f.exceptionally((e) -> {
                output("As expected, this future completed exceptionally");
                return false;
            });
        });

        // make sure we don't get into any data races
        // thread pool might shutdown before we get to start worker threads
        Thread.sleep(10);

        output("[1/4] Attempting to cancel all futures");
        futures.forEach(f -> cancel(f));
        output("[2/4] Cancelled all futures");

        output("[3/4] Supplying new job to thread pool - should finish immediately");
        CompletableFuture<Boolean> completeImmediately = CompletableFuture.supplyAsync(() -> true, threadPool);
        completeImmediately.join();
        output("[4/4] Finished all jobs");

        threadPool.shutdown();
    }

    private static void cancel(CompletableFuture<Boolean> future) {
        try {
            future.cancel(true);
        } catch (CancellationException exception) {
            // there will be many, for the sake of exercise we can swallow this exception
        }
    }

    static class Worker implements Supplier<Boolean> {

        private volatile boolean run = true;

        void stop() {
            this.run = false;
        }

        @Override
        public Boolean get() {
            while (run) {
                // running && sleeping
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            return true;
        }
    }
}
