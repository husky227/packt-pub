package com.adamdubiel.workshop.tuning.memorymodel;

public interface Counter {

    void add();

    int value();

}
